import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1f404aa4 = () => interopDefault(import('../src/pages/403.vue' /* webpackChunkName: "pages/403" */))
const _53fc3f62 = () => interopDefault(import('../src/pages/500.vue' /* webpackChunkName: "pages/500" */))
const _2dc9d68d = () => interopDefault(import('../src/pages/contact.vue' /* webpackChunkName: "pages/contact" */))
const _268b7c96 = () => interopDefault(import('../src/pages/error.vue' /* webpackChunkName: "pages/error" */))
const _4d0e2842 = () => interopDefault(import('../src/pages/home.vue' /* webpackChunkName: "pages/home" */))
const _ab35fd00 = () => interopDefault(import('../src/pages/maintenance.vue' /* webpackChunkName: "pages/maintenance" */))
const _79249f5d = () => interopDefault(import('../src/pages/man-hour/index.vue' /* webpackChunkName: "pages/man-hour/index" */))
const _52f1e1b4 = () => interopDefault(import('../src/pages/terms.vue' /* webpackChunkName: "pages/terms" */))
const _124d613e = () => interopDefault(import('../src/pages/user-policy.vue' /* webpackChunkName: "pages/user-policy" */))
const _3adfe5ec = () => interopDefault(import('../src/pages/anonymous-survey/auth.vue' /* webpackChunkName: "pages/anonymous-survey/auth" */))
const _1e964948 = () => interopDefault(import('../src/pages/customer/list.vue' /* webpackChunkName: "pages/customer/list" */))
const _193194fa = () => interopDefault(import('../src/pages/project/list/index.vue' /* webpackChunkName: "pages/project/list/index" */))
const _7680d635 = () => interopDefault(import('../src/pages/sample/assets.vue' /* webpackChunkName: "pages/sample/assets" */))
const _36096212 = () => interopDefault(import('../src/pages/solver/application.vue' /* webpackChunkName: "pages/solver/application" */))
const _705a8448 = () => interopDefault(import('../src/pages/solver/menu.vue' /* webpackChunkName: "pages/solver/menu" */))
const _42094ba0 = () => interopDefault(import('../src/pages/project/list/me.vue' /* webpackChunkName: "pages/project/list/me" */))
const _e98a18aa = () => interopDefault(import('../src/pages/solver/candidate/application.vue' /* webpackChunkName: "pages/solver/candidate/application" */))
const _ab3ae040 = () => interopDefault(import('../src/pages/survey/admin/list.vue' /* webpackChunkName: "pages/survey/admin/list" */))
const _a339aa8a = () => interopDefault(import('../src/pages/survey/pp/list.vue' /* webpackChunkName: "pages/survey/pp/list" */))
const _8ffb1e1c = () => interopDefault(import('../src/pages/solver/candidate/certification/_solver_id.vue' /* webpackChunkName: "pages/solver/candidate/certification/_solver_id" */))
const _5de4bfc6 = () => interopDefault(import('../src/pages/solver/candidate/list/_solverCorporationId.vue' /* webpackChunkName: "pages/solver/candidate/list/_solverCorporationId" */))
const _1480c4de = () => interopDefault(import('../src/pages/karte/list/_projectId.vue' /* webpackChunkName: "pages/karte/list/_projectId" */))
const _f35fd486 = () => interopDefault(import('../src/pages/solver/candidate/_solver_id.vue' /* webpackChunkName: "pages/solver/candidate/_solver_id" */))
const _66e91f58 = () => interopDefault(import('../src/pages/solver/corporation/_corporationId.vue' /* webpackChunkName: "pages/solver/corporation/_corporationId" */))
const _7293732e = () => interopDefault(import('../src/pages/solver/list/_solverCorporationId.vue' /* webpackChunkName: "pages/solver/list/_solverCorporationId" */))
const _1fce382c = () => interopDefault(import('../src/pages/solver/utilization-rate/_solver_corporation_id.vue' /* webpackChunkName: "pages/solver/utilization-rate/_solver_corporation_id" */))
const _6bdf8b94 = () => interopDefault(import('../src/pages/survey/list/_projectId.vue' /* webpackChunkName: "pages/survey/list/_projectId" */))
const _ab555eb2 = () => interopDefault(import('../src/pages/survey/pp/_surveyId.vue' /* webpackChunkName: "pages/survey/pp/_surveyId" */))
const _218ea982 = () => interopDefault(import('../src/pages/anonymous-survey/_surveyId.vue' /* webpackChunkName: "pages/anonymous-survey/_surveyId" */))
const _042b87ea = () => interopDefault(import('../src/pages/customer/_customerId.vue' /* webpackChunkName: "pages/customer/_customerId" */))
const _7f6317a4 = () => interopDefault(import('../src/pages/karte/_karteId.vue' /* webpackChunkName: "pages/karte/_karteId" */))
const _fa059836 = () => interopDefault(import('../src/pages/master-karte/_npfProjectId.vue' /* webpackChunkName: "pages/master-karte/_npfProjectId" */))
const _4dea1124 = () => interopDefault(import('../src/pages/project/_projectId.vue' /* webpackChunkName: "pages/project/_projectId" */))
const _380c8acd = () => interopDefault(import('../src/pages/satisfaction-survey/_surveyId.vue' /* webpackChunkName: "pages/satisfaction-survey/_surveyId" */))
const _548be658 = () => interopDefault(import('../src/pages/solver/_solverId.vue' /* webpackChunkName: "pages/solver/_solverId" */))
const _618401e2 = () => interopDefault(import('../src/pages/survey/_surveyId.vue' /* webpackChunkName: "pages/survey/_surveyId" */))
const _2be39bce = () => interopDefault(import('../src/pages/man-hour/_year/_month.vue' /* webpackChunkName: "pages/man-hour/_year/_month" */))
const _ae17b902 = () => interopDefault(import('../src/pages/index.vue' /* webpackChunkName: "pages/index" */))
const _0a49cedc = () => interopDefault(import('../src/pages/_404.vue' /* webpackChunkName: "pages/_404" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/403",
    component: _1f404aa4,
    name: "403___ja"
  }, {
    path: "/500",
    component: _53fc3f62,
    name: "500___ja"
  }, {
    path: "/contact",
    component: _2dc9d68d,
    name: "contact___ja"
  }, {
    path: "/error",
    component: _268b7c96,
    name: "error___ja"
  }, {
    path: "/home",
    component: _4d0e2842,
    name: "home___ja"
  }, {
    path: "/maintenance",
    component: _ab35fd00,
    name: "maintenance___ja"
  }, {
    path: "/man-hour",
    component: _79249f5d,
    name: "man-hour___ja"
  }, {
    path: "/terms",
    component: _52f1e1b4,
    name: "terms___ja"
  }, {
    path: "/user-policy",
    component: _124d613e,
    name: "user-policy___ja"
  }, {
    path: "/anonymous-survey/auth",
    component: _3adfe5ec,
    name: "anonymous-survey-auth___ja"
  }, {
    path: "/customer/list",
    component: _1e964948,
    name: "customer-list___ja"
  }, {
    path: "/project/list",
    component: _193194fa,
    name: "project-list___ja"
  }, {
    path: "/sample/assets",
    component: _7680d635,
    name: "sample-assets___ja"
  }, {
    path: "/solver/application",
    component: _36096212,
    name: "solver-application___ja"
  }, {
    path: "/solver/menu",
    component: _705a8448,
    name: "solver-menu___ja"
  }, {
    path: "/project/list/me",
    component: _42094ba0,
    name: "project-list-me___ja"
  }, {
    path: "/solver/candidate/application",
    component: _e98a18aa,
    name: "solver-candidate-application___ja"
  }, {
    path: "/survey/admin/list",
    component: _ab3ae040,
    name: "survey-admin-list___ja"
  }, {
    path: "/survey/pp/list",
    component: _a339aa8a,
    name: "survey-pp-list___ja"
  }, {
    path: "/solver/candidate/certification/:solver_id?",
    component: _8ffb1e1c,
    name: "solver-candidate-certification-solver_id___ja"
  }, {
    path: "/solver/candidate/list/:solverCorporationId?",
    component: _5de4bfc6,
    name: "solver-candidate-list-solverCorporationId___ja"
  }, {
    path: "/karte/list/:projectId?",
    component: _1480c4de,
    name: "karte-list-projectId___ja"
  }, {
    path: "/solver/candidate/:solver_id?",
    component: _f35fd486,
    name: "solver-candidate-solver_id___ja"
  }, {
    path: "/solver/corporation/:corporationId?",
    component: _66e91f58,
    name: "solver-corporation-corporationId___ja"
  }, {
    path: "/solver/list/:solverCorporationId?",
    component: _7293732e,
    name: "solver-list-solverCorporationId___ja"
  }, {
    path: "/solver/utilization-rate/:solver_corporation_id?",
    component: _1fce382c,
    name: "solver-utilization-rate-solver_corporation_id___ja"
  }, {
    path: "/survey/list/:projectId?",
    component: _6bdf8b94,
    name: "survey-list-projectId___ja"
  }, {
    path: "/survey/pp/:surveyId?",
    component: _ab555eb2,
    name: "survey-pp-surveyId___ja"
  }, {
    path: "/anonymous-survey/:surveyId?",
    component: _218ea982,
    name: "anonymous-survey-surveyId___ja"
  }, {
    path: "/customer/:customerId?",
    component: _042b87ea,
    name: "customer-customerId___ja"
  }, {
    path: "/karte/:karteId?",
    component: _7f6317a4,
    name: "karte-karteId___ja"
  }, {
    path: "/master-karte/:npfProjectId?",
    component: _fa059836,
    name: "master-karte-npfProjectId___ja"
  }, {
    path: "/project/:projectId?",
    component: _4dea1124,
    name: "project-projectId___ja"
  }, {
    path: "/satisfaction-survey/:surveyId?",
    component: _380c8acd,
    name: "satisfaction-survey-surveyId___ja"
  }, {
    path: "/solver/:solverId?",
    component: _548be658,
    name: "solver-solverId___ja"
  }, {
    path: "/survey/:surveyId?",
    component: _618401e2,
    name: "survey-surveyId___ja"
  }, {
    path: "/man-hour/:year?/:month",
    component: _2be39bce,
    name: "man-hour-year-month___ja"
  }, {
    path: "/",
    component: _ae17b902,
    name: "index___ja"
  }, {
    path: "/:404",
    component: _0a49cedc,
    name: "404___ja"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
