const middleware = {}

middleware['roleCheck'] = require('../src/middleware/roleCheck.ts')
middleware['roleCheck'] = middleware['roleCheck'].default || middleware['roleCheck']

export default middleware
