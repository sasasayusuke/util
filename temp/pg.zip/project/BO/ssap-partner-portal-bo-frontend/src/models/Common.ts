export class OkResponse {
  message: string = ''
}
