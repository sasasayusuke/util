/*
  定数を格納するファイル
  ※環境変数はenvファイルに、enumはtypesに格納するように！
  import { Const } from '~/const'
 */

export const Const = {
  MIN_FISCAL_YEAR: 2021,
} as const
