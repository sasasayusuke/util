/**
 * ページの基底クラス
 */

import BaseVueClass from './BaseVueClass'

export default BaseVueClass.extend({
  data() {
    return {}
  },
})
