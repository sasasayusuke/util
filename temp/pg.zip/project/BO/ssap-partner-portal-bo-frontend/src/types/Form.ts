export interface FormModel {
  valid: boolean
  value: {
    [key: string]: any
  }
}
