---
name: 積み残し
about: 積み残しタスク
title: '【積み残し】'
labels:
assignees: ''
---

## 概要（現状）

## タスク完了条件
