import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _7ac361b8 = () => interopDefault(import('../src/pages/403.vue' /* webpackChunkName: "pages/403" */))
const _114b783c = () => interopDefault(import('../src/pages/500.vue' /* webpackChunkName: "pages/500" */))
const _1570b3c2 = () => interopDefault(import('../src/pages/home.vue' /* webpackChunkName: "pages/home" */))
const _43b68600 = () => interopDefault(import('../src/pages/maintenance.vue' /* webpackChunkName: "pages/maintenance" */))
const _4e6ecadd = () => interopDefault(import('../src/pages/man-hour/index.vue' /* webpackChunkName: "pages/man-hour/index" */))
const _6b131b18 = () => interopDefault(import('../src/pages/otp.vue' /* webpackChunkName: "pages/otp" */))
const _5c278280 = () => interopDefault(import('../src/pages/survey/index.vue' /* webpackChunkName: "pages/survey/index" */))
const _d23e7398 = () => interopDefault(import('../src/pages/terms.vue' /* webpackChunkName: "pages/terms" */))
const _5b82051f = () => interopDefault(import('../src/pages/admin/create.vue' /* webpackChunkName: "pages/admin/create" */))
const _24feda81 = () => interopDefault(import('../src/pages/admin/list.vue' /* webpackChunkName: "pages/admin/list" */))
const _3493008c = () => interopDefault(import('../src/pages/customer/create.vue' /* webpackChunkName: "pages/customer/create" */))
const _1cf3b3b4 = () => interopDefault(import('../src/pages/customer/import/index.vue' /* webpackChunkName: "pages/customer/import/index" */))
const _7bb73fdc = () => interopDefault(import('../src/pages/customer/list.vue' /* webpackChunkName: "pages/customer/list" */))
const _87c7c2f4 = () => interopDefault(import('../src/pages/karte/list/index.vue' /* webpackChunkName: "pages/karte/list/index" */))
const _7033abf6 = () => interopDefault(import('../src/pages/master/create.vue' /* webpackChunkName: "pages/master/create" */))
const _7eca4b18 = () => interopDefault(import('../src/pages/master/list.vue' /* webpackChunkName: "pages/master/list" */))
const _173ed455 = () => interopDefault(import('../src/pages/project/create.vue' /* webpackChunkName: "pages/project/create" */))
const _6fe55a81 = () => interopDefault(import('../src/pages/project/import/index.vue' /* webpackChunkName: "pages/project/import/index" */))
const _10f1ff37 = () => interopDefault(import('../src/pages/project/list.vue' /* webpackChunkName: "pages/project/list" */))
const _01833ab5 = () => interopDefault(import('../src/pages/sample/assets.vue' /* webpackChunkName: "pages/sample/assets" */))
const _0e24e520 = () => interopDefault(import('../src/pages/survey/list.vue' /* webpackChunkName: "pages/survey/list" */))
const _a6d57fa6 = () => interopDefault(import('../src/pages/user/create.vue' /* webpackChunkName: "pages/user/create" */))
const _97bcfde2 = () => interopDefault(import('../src/pages/user/list.vue' /* webpackChunkName: "pages/user/list" */))
const _a80583d8 = () => interopDefault(import('../src/pages/customer/import/confirm.vue' /* webpackChunkName: "pages/customer/import/confirm" */))
const _5ac44c44 = () => interopDefault(import('../src/pages/customer/import/done.vue' /* webpackChunkName: "pages/customer/import/done" */))
const _21825b9a = () => interopDefault(import('../src/pages/man-hour/alert/config.vue' /* webpackChunkName: "pages/man-hour/alert/config" */))
const _94c3aa14 = () => interopDefault(import('../src/pages/man-hour/alert/list.vue' /* webpackChunkName: "pages/man-hour/alert/list" */))
const _0f60c7af = () => interopDefault(import('../src/pages/project/import/confirm.vue' /* webpackChunkName: "pages/project/import/confirm" */))
const _94ada3ba = () => interopDefault(import('../src/pages/project/import/done.vue' /* webpackChunkName: "pages/project/import/done" */))
const _733e91b7 = () => interopDefault(import('../src/pages/survey/master/create.vue' /* webpackChunkName: "pages/survey/master/create" */))
const _2b25ad19 = () => interopDefault(import('../src/pages/survey/master/list.vue' /* webpackChunkName: "pages/survey/master/list" */))
const _7bae20e4 = () => interopDefault(import('../src/pages/survey/report/forecast.vue' /* webpackChunkName: "pages/survey/report/forecast" */))
const _e4963f10 = () => interopDefault(import('../src/pages/survey/report/forecast-survey-ops.vue' /* webpackChunkName: "pages/survey/report/forecast-survey-ops" */))
const _72b75c34 = () => interopDefault(import('../src/pages/survey/report/monthly.vue' /* webpackChunkName: "pages/survey/report/monthly" */))
const _3c558211 = () => interopDefault(import('../src/pages/karte/list/_projectId.vue' /* webpackChunkName: "pages/karte/list/_projectId" */))
const _3a2ed7ce = () => interopDefault(import('../src/pages/survey/master/_surveyMasterId/index.vue' /* webpackChunkName: "pages/survey/master/_surveyMasterId/index" */))
const _7234c01d = () => interopDefault(import('../src/pages/man-hour/report/_year/_month/index.vue' /* webpackChunkName: "pages/man-hour/report/_year/_month/index" */))
const _4584dccf = () => interopDefault(import('../src/pages/man-hour/supporter/_year/_month/index.vue' /* webpackChunkName: "pages/man-hour/supporter/_year/_month/index" */))
const _f3f45b94 = () => interopDefault(import('../src/pages/survey/master/_surveyMasterId/_revision.vue' /* webpackChunkName: "pages/survey/master/_surveyMasterId/_revision" */))
const _6ee0c624 = () => interopDefault(import('../src/pages/man-hour/report/_year/_month/project.vue' /* webpackChunkName: "pages/man-hour/report/_year/_month/project" */))
const _35f8bf88 = () => interopDefault(import('../src/pages/man-hour/alert/_year/_month/_projectId.vue' /* webpackChunkName: "pages/man-hour/alert/_year/_month/_projectId" */))
const _746658a2 = () => interopDefault(import('../src/pages/man-hour/supporter/_year/_month/_userId.vue' /* webpackChunkName: "pages/man-hour/supporter/_year/_month/_userId" */))
const _126ae96e = () => interopDefault(import('../src/pages/admin/_adminId.vue' /* webpackChunkName: "pages/admin/_adminId" */))
const _5907136a = () => interopDefault(import('../src/pages/customer/_customerId.vue' /* webpackChunkName: "pages/customer/_customerId" */))
const _d4cec0a4 = () => interopDefault(import('../src/pages/karte/_karteId.vue' /* webpackChunkName: "pages/karte/_karteId" */))
const _063bc136 = () => interopDefault(import('../src/pages/master-karte/_npfProjectId.vue' /* webpackChunkName: "pages/master-karte/_npfProjectId" */))
const _5e5362ee = () => interopDefault(import('../src/pages/project/_projectId.vue' /* webpackChunkName: "pages/project/_projectId" */))
const _0cf14d62 = () => interopDefault(import('../src/pages/survey/_surveyId.vue' /* webpackChunkName: "pages/survey/_surveyId" */))
const _d839a7f8 = () => interopDefault(import('../src/pages/user/_userId.vue' /* webpackChunkName: "pages/user/_userId" */))
const _56f83c46 = () => interopDefault(import('../src/pages/master/_dataType/_masterId.vue' /* webpackChunkName: "pages/master/_dataType/_masterId" */))
const _2639f002 = () => interopDefault(import('../src/pages/index.vue' /* webpackChunkName: "pages/index" */))
const _5aa74b48 = () => interopDefault(import('../src/pages/_404.vue' /* webpackChunkName: "pages/_404" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/403",
    component: _7ac361b8,
    name: "403___ja"
  }, {
    path: "/500",
    component: _114b783c,
    name: "500___ja"
  }, {
    path: "/home",
    component: _1570b3c2,
    name: "home___ja"
  }, {
    path: "/maintenance",
    component: _43b68600,
    name: "maintenance___ja"
  }, {
    path: "/man-hour",
    component: _4e6ecadd,
    name: "man-hour___ja"
  }, {
    path: "/otp",
    component: _6b131b18,
    name: "otp___ja"
  }, {
    path: "/survey",
    component: _5c278280,
    name: "survey___ja"
  }, {
    path: "/terms",
    component: _d23e7398,
    name: "terms___ja"
  }, {
    path: "/admin/create",
    component: _5b82051f,
    name: "admin-create___ja"
  }, {
    path: "/admin/list",
    component: _24feda81,
    name: "admin-list___ja"
  }, {
    path: "/customer/create",
    component: _3493008c,
    name: "customer-create___ja"
  }, {
    path: "/customer/import",
    component: _1cf3b3b4,
    name: "customer-import___ja"
  }, {
    path: "/customer/list",
    component: _7bb73fdc,
    name: "customer-list___ja"
  }, {
    path: "/karte/list",
    component: _87c7c2f4,
    name: "karte-list___ja"
  }, {
    path: "/master/create",
    component: _7033abf6,
    name: "master-create___ja"
  }, {
    path: "/master/list",
    component: _7eca4b18,
    name: "master-list___ja"
  }, {
    path: "/project/create",
    component: _173ed455,
    name: "project-create___ja"
  }, {
    path: "/project/import",
    component: _6fe55a81,
    name: "project-import___ja"
  }, {
    path: "/project/list",
    component: _10f1ff37,
    name: "project-list___ja"
  }, {
    path: "/sample/assets",
    component: _01833ab5,
    name: "sample-assets___ja"
  }, {
    path: "/survey/list",
    component: _0e24e520,
    name: "survey-list___ja"
  }, {
    path: "/user/create",
    component: _a6d57fa6,
    name: "user-create___ja"
  }, {
    path: "/user/list",
    component: _97bcfde2,
    name: "user-list___ja"
  }, {
    path: "/customer/import/confirm",
    component: _a80583d8,
    name: "customer-import-confirm___ja"
  }, {
    path: "/customer/import/done",
    component: _5ac44c44,
    name: "customer-import-done___ja"
  }, {
    path: "/man-hour/alert/config",
    component: _21825b9a,
    name: "man-hour-alert-config___ja"
  }, {
    path: "/man-hour/alert/list",
    component: _94c3aa14,
    name: "man-hour-alert-list___ja"
  }, {
    path: "/project/import/confirm",
    component: _0f60c7af,
    name: "project-import-confirm___ja"
  }, {
    path: "/project/import/done",
    component: _94ada3ba,
    name: "project-import-done___ja"
  }, {
    path: "/survey/master/create",
    component: _733e91b7,
    name: "survey-master-create___ja"
  }, {
    path: "/survey/master/list",
    component: _2b25ad19,
    name: "survey-master-list___ja"
  }, {
    path: "/survey/report/forecast",
    component: _7bae20e4,
    name: "survey-report-forecast___ja"
  }, {
    path: "/survey/report/forecast-survey-ops",
    component: _e4963f10,
    name: "survey-report-forecast-survey-ops___ja"
  }, {
    path: "/survey/report/monthly",
    component: _72b75c34,
    name: "survey-report-monthly___ja"
  }, {
    path: "/karte/list/:projectId",
    component: _3c558211,
    name: "karte-list-projectId___ja"
  }, {
    path: "/survey/master/:surveyMasterId",
    component: _3a2ed7ce,
    name: "survey-master-surveyMasterId___ja"
  }, {
    path: "/man-hour/report/:year/:month",
    component: _7234c01d,
    name: "man-hour-report-year-month___ja"
  }, {
    path: "/man-hour/supporter/:year/:month",
    component: _4584dccf,
    name: "man-hour-supporter-year-month___ja"
  }, {
    path: "/survey/master/:surveyMasterId?/:revision",
    component: _f3f45b94,
    name: "survey-master-surveyMasterId-revision___ja"
  }, {
    path: "/man-hour/report/:year/:month?/project",
    component: _6ee0c624,
    name: "man-hour-report-year-month-project___ja"
  }, {
    path: "/man-hour/alert/:year/:month?/:projectId?",
    component: _35f8bf88,
    name: "man-hour-alert-year-month-projectId___ja"
  }, {
    path: "/man-hour/supporter/:year/:month?/:userId?",
    component: _746658a2,
    name: "man-hour-supporter-year-month-userId___ja"
  }, {
    path: "/admin/:adminId?",
    component: _126ae96e,
    name: "admin-adminId___ja"
  }, {
    path: "/customer/:customerId?",
    component: _5907136a,
    name: "customer-customerId___ja"
  }, {
    path: "/karte/:karteId?",
    component: _d4cec0a4,
    name: "karte-karteId___ja"
  }, {
    path: "/master-karte/:npfProjectId?",
    component: _063bc136,
    name: "master-karte-npfProjectId___ja"
  }, {
    path: "/project/:projectId?",
    component: _5e5362ee,
    name: "project-projectId___ja"
  }, {
    path: "/survey/:surveyId",
    component: _0cf14d62,
    name: "survey-surveyId___ja"
  }, {
    path: "/user/:userId?",
    component: _d839a7f8,
    name: "user-userId___ja"
  }, {
    path: "/master/:dataType?/:masterId?",
    component: _56f83c46,
    name: "master-dataType-masterId___ja"
  }, {
    path: "/",
    component: _2639f002,
    name: "index___ja"
  }, {
    path: "/:404",
    component: _5aa74b48,
    name: "404___ja"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
