const middleware = {}

middleware['beforeLogin'] = require('../src/middleware/beforeLogin.ts')
middleware['beforeLogin'] = middleware['beforeLogin'].default || middleware['beforeLogin']

middleware['roleCheck'] = require('../src/middleware/roleCheck.ts')
middleware['roleCheck'] = middleware['roleCheck'].default || middleware['roleCheck']

export default middleware
