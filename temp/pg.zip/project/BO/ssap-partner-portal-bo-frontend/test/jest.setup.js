import Vue from 'vue'

Vue.config.silent = true
